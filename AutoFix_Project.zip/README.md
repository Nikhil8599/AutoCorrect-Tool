# AutoFix - Grammar & Spell Checker

AutoFix is a simple web application that checks and corrects grammar and spelling in user-provided text using Flask, TextBlob, and LanguageTool.

## Features
- Spelling correction using TextBlob
- Grammar checking and correction using LanguageTool
- Clean and minimal Bootstrap-based UI

## Technologies Used
- Python
- Flask
- TextBlob
- LanguageTool
- Bootstrap 5

## Setup Instructions

### 1. Clone the repository
```bash
git clone https://github.com/your-username/autofix.git
cd autofix
```

### 2. Create a virtual environment (optional but recommended)
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Run the app
```bash
python app.py
```

### 5. Open in browser
Go to `http://127.0.0.1:5000/` in your browser to use the app.

---

## Folder Structure
```
AutoFix/
├── app.py
├── model.py
├── requirements.txt
├── README.md
├── .gitignore
├── /templates/
│   └── index.html
└── /static/
    └── (optional for CSS or JS)
```

## License
MIT License
